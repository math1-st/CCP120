require("colors");

// inclui o modulo http
var http = require('http');
// inclui o modulo express
var express = require('express');

// cria a variavel app, pela qual acessaremos
// os metodos / funcoes existentes no framework
// express
var app = express() ;

// metodo use() utilizado para definir em qual
// pasta estara o conteudo estatico
app. use (express. static ('./public'));

// cria o servidor
var server = http.createServer(app);

// define o numero da porta que o servidor ouvira
server.listen(80);

// mensagem exibida no console para debug
console. log("Servidor rodando...".rainbow);